/************************************************************************/
/*  Loudness calculation according to ISO 532-1,                        */
/*  methods for stationary and time varying signals                     */
/*  Helper methods                                                      */
/************************************************************************/

#include "ISO_532-1.h"
#include "ISO_532-1_helper.h"

/*	M_PI should be defined in math.h									*/
#define _USE_MATH_DEFINES

#include <math.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <locale.h>

#ifndef M_PI
#define M_PI			acos(-1)
#endif

#ifndef isnan
#define isnan(x) ((x) != (x))
#endif

struct KaiserBessel
{
	double	BetaKaiser
		,	BesselOfBeta
		,	Length
		,	SquareLenHalf;
};

/*	Output of error messages											*/
void f_print_err_msg_and_exit(const char *pMsg)
{
	printf("An error occurred:\n%s\n", pMsg);
	exit(-1);
}

//////////////////////////////////////////////////////////////////////////
//	BLOCK	Resampling												    
//////////////////////////////////////////////////////////////////////////

/*  For resampling														*/
double f_modified_bessel0(double X)
{
	double	X2 = X * X
		,	DS = 1.0
		,	DD = 0.0
		,	Y  = 1.0;

	do
	{
		DD += 2.0;
		DS *= X2 / (DD * DD);
		Y  += DS;
	} while (DS >= 1e-14 * Y);

	return Y;
}

/*  For resampling														*/
void f_kaiser_bessel_init(struct KaiserBessel *KB, double Length,
	int Denominator)
{
	/*	Formfactor kaiser window -> 90 dB damping						*/
	double	BETA_KAISER_MAX = 8.96;
	/*	Formfactor kaiser window -> 70 dB damping						*/
	double	BETA_KAISER_MIN = 6.75;
	double	DELTA_F_MAX = 0.07;

	double	BetaKaiser = BETA_KAISER_MAX;
	double	DeltaF = (double)Denominator * (BetaKaiser / 0.1102 + 0.7) /
						(2.0 * M_PI * 2.285 * Length);

	if (DeltaF > DELTA_F_MAX)
	{
		BetaKaiser = (2.285 * Length * 2.0 * M_PI * DELTA_F_MAX - 0.7) *
						0.1102 / (double)Denominator;
	}
	if (BetaKaiser < BETA_KAISER_MIN)
		BetaKaiser = BETA_KAISER_MIN;

	KB->BetaKaiser		= BetaKaiser;
	KB->Length			= Length;
	KB->BesselOfBeta	= f_modified_bessel0(BetaKaiser);
	KB->SquareLenHalf	= pow(Length / 2.0, 2);
}

/*  For resampling														*/
double f_kaiser_bessel_calculate(double X, struct KaiserBessel *KB)
{
	double	ArgBessel;
	double	ArgSqrt = 1.0 - X * X / KB->SquareLenHalf;

	if (ArgSqrt >= 0.0)
		ArgBessel = KB->BetaKaiser * sqrt(ArgSqrt);
	else
		ArgBessel = 0.0;

	return f_modified_bessel0(ArgBessel) / KB->BesselOfBeta;
}

/*  Si function															*/
double f_si(double X)
{
	if (X == 0)
		return 1;
	else
		return (sin(X) / X);
}

/*  Calculates impulse response of FIR filter: filter coefficients for
	resampling lowpass													*/
void f_create_resampling_filter(int NumImpResp, int Numerator,
	struct KaiserBessel KB, double* pFiltImpResp)
{
	int		IdxImpR;
	double	X;
	double	CoefSum = 0;
	double	*pCoeffs;

	pCoeffs = pFiltImpResp;

	for (IdxImpR = 0, X = -0.5 * floor((double)NumImpResp - 1);
		IdxImpR < NumImpResp; IdxImpR++, X += 1.0)
	{
		*pCoeffs = f_si(M_PI / Numerator * X) * 
						f_kaiser_bessel_calculate(X, &KB);
		CoefSum += *pCoeffs;
		pCoeffs++;
	}

	if (CoefSum != 0)
	{
		double Factor = Numerator / CoefSum;

		pCoeffs = pFiltImpResp;

		for (IdxImpR = 0; IdxImpR < NumImpResp; IdxImpR++)
		{
			*pCoeffs *= Factor;
			pCoeffs++;
		}
	}
}

/*  Lowpass filtering and decimation
	pInput contains samples which are on Numerator'th position in
	upsampled signal, which are only samples != 0,
	pOutput will contain result of filtering the Denominator'th
	samples in upsampled signal											*/
void f_resample_filter(double *pInput, double *pOutput,
	double *pFiltImpResp, int NumInSamples,
	int NumOutSamples, int NumCoeffs,
	int Denominator, int Numerator, int Delay)
{
	int		IdxOut, IdxLastS, IdxIn, IdxImpR, Diff, Offset;
	double	*pCoeffs, *pIn;

	for (IdxOut = Delay; IdxOut < NumOutSamples + Delay; IdxOut++)
	{
		pCoeffs = pFiltImpResp;

		/*	Difference between i'th Denominator'th sample to previous
			Numerator'th sample (!=0), distance to last sample != 0		*/
		Diff = (IdxOut * Denominator) % Numerator;

		/*	Last sample != 0											*/
		IdxLastS = IdxOut * Denominator / Numerator;
		/*	Corresponding filter coefficient							*/
		pCoeffs += Diff;
		IdxImpR  = Diff;

		/* Zero padding of input signal									*/
		if (IdxLastS - NumInSamples >= 0)
		{
			Offset   = (IdxLastS - NumInSamples + 1) * Numerator;
			pCoeffs += Offset;
			IdxImpR += Offset;
			IdxLastS = NumInSamples - 1;
		}

		/*	Filtering													*/
		for (IdxIn = IdxLastS, pIn = pInput + IdxIn; IdxIn >= 0 && 
			IdxImpR <= NumCoeffs; IdxIn--, IdxImpR += Numerator)
		{
			*pOutput += *pIn * *pCoeffs;
			pCoeffs  += Numerator;
			pIn--;
		}
		pOutput++;
	}
}

/*  Resamples signal from 44.1kHz or 32kHz to 48kHz						*/
int f_resample_to_48kHz(struct InputData *pSignal)
{
	int		Numerator, Denominator, NumImpResp, Lhalf;
	int		FilterOrder = 256;
	int		NumSamplesOld = pSignal->NumSamples;
	int		NumSamples, Delay;
	double	SampleRateOld = pSignal->SampleRate;
	double	*pFiltImpResp, *pResampledSignal;
	struct	KaiserBessel KB;

	if (SampleRateOld == 32000)
	{
		/*	Upsampling by Numerator, downsampling by Denominator		*/
		Numerator	= 3;
		Denominator = 2;
	}
	else if (SampleRateOld == 44100)
	{
		/*	Upsampling by Numerator, downsampling by Denominator		*/
		Numerator	= 160;
		Denominator = 147;
	}
	else
	{
		/*	Mot supported												*/
		Numerator	= 1;
		Denominator = 1;
	}

	NumImpResp = FilterOrder * Numerator;
	/*	Number of samples should be odd									*/
	NumImpResp = (int)floor(NumImpResp / 2.0) * 2 + 1;
	/*	Half length	without sample in the center						*/
	Lhalf = (NumImpResp - 1) / 2;
	/*	Half length is multiple of denominator							*/
	Lhalf -= (Lhalf % Denominator);
	NumImpResp = 2 * Lhalf + 1;
	/*	Delay for zero padding at end of input							*/
	Delay = Lhalf / Denominator;

	f_kaiser_bessel_init(&KB, NumImpResp, Denominator);

	pFiltImpResp = (double*)calloc(NumImpResp, sizeof(double));
	if (pFiltImpResp == NULL)
	{
		return LoudnessErrorMemoryAllocFailed;
	}

	f_create_resampling_filter(NumImpResp, Numerator, KB, pFiltImpResp);
	NumSamples = (NumSamplesOld*Numerator) / Denominator;

	pResampledSignal = (double*)calloc(NumSamples, sizeof(double));
	if (pResampledSignal == NULL)
	{
		free(pFiltImpResp);
		return LoudnessErrorMemoryAllocFailed;
	}

	/*	Resampling														*/
	f_resample_filter(pSignal->pData, pResampledSignal, pFiltImpResp,
		NumSamplesOld, NumSamples, NumImpResp, Denominator,
		Numerator, Delay);

	free(pSignal->pData);
	free(pFiltImpResp);

	pSignal->pData = pResampledSignal;
	pSignal->SampleRate = 48000;
	pSignal->NumSamples = NumSamples;

	return 0;
}

//////////////////////////////////////////////////////////////////////////
//	BLOCK	Read WAVE file
//////////////////////////////////////////////////////////////////////////

#define	PCM			0x0001
#define	IEEE_FLOAT	0x0003

/*  Read wav input-file													*/
int f_read_wavfile(const char *pFileName, struct InputData *Input)
{
	int		IdxTime;
	short	*pTemp16;
	float	*pTemp32;
	double	*pData;

	int     NanFoundInFile;
	int     retval;

	FILE	*pfile;

#if	USE_SECURE_CRT_FCTS
	errno_t Err;
#endif

	/*	Wavefile structure	*/
	struct wavfile
	{
		char	Id[4];
		short	FormatTag, Channels, BlockAlign, BitsPerSample, *pTemp16;
		float	*pTemp32;
		int		Size, FormatLength, SampleRate, BytesSec, DataSize,
			Successful, ExtraParam, NumSamples;
		double	*pData;
	}	Signal;

#if	USE_SECURE_CRT_FCTS
	Err = fopen_s(&pfile, pFileName, "rb");
	if (Err == 0)
#else
	pfile = fopen(pFileName, "rb");
	if (pfile != 0)
#endif
	{
		/*	ID, should be RIFF											*/
		fread(Signal.Id, sizeof(char), 4, pfile);
		if (strncmp(Signal.Id, "RIFF", 4) == 0)
		{
			/*	Size-8													*/
			fread(&Signal.Size, sizeof(int), 1, pfile);
			/*	ID, should be WAVE										*/
			fread(Signal.Id, sizeof(char), 4, pfile);
			if (strncmp(Signal.Id, "WAVE", 4) == 0)
			{
				/*	Format string										*/
				fread(Signal.Id, sizeof(char), 4, pfile);
				/*	Format length										*/
				fread(&Signal.FormatLength, sizeof(long), 1, pfile);
				/*	Format tag, only PCM or IEEE FLOAT supported		*/
				fread(&Signal.FormatTag, sizeof(short), 1, pfile);
				if (Signal.FormatTag == PCM || Signal.FormatTag == IEEE_FLOAT)
				{
					/*	Channels, only one channel supported			*/
					fread(&Signal.Channels, sizeof(short), 1, pfile);
					if (Signal.Channels == 1)
					{
						/*	Sample rate									*/
						fread(&Signal.SampleRate, sizeof(long), 1, pfile);
						/*	Bytes/second								*/
						fread(&Signal.BytesSec, sizeof(long), 1, pfile);
						/*	Frame size, number of bytes/sample			*/
						fread(&Signal.BlockAlign, sizeof(short), 1, pfile);
						/*	Bits/sample									*/
						fread(&Signal.BitsPerSample, sizeof(short), 1, pfile);
						if (Signal.FormatLength != 16)
							fread(&Signal.ExtraParam, sizeof(short), 1, pfile);
						/*	Signature, should be 'data'					*/
						fread(Signal.Id, sizeof(char), 4, pfile);
						if (strncmp(Signal.Id, "data", 4) == 0)
						{
							/*	Number of bytes in data block			*/
							fread(&Signal.DataSize, sizeof(int), 1, pfile);
							Signal.NumSamples = Signal.DataSize / Signal.BlockAlign;
							/*	16-bit data								*/
							if (Signal.BitsPerSample == 16)
							{
								Input->pData = (double*)calloc(Signal.NumSamples,
									sizeof(double));
								if (Input->pData == NULL)
								{
									f_print_err_msg_and_exit("memory allocation"
										" not succeeded");
								}
								Signal.pTemp16 = (short*)calloc(Signal.NumSamples,
									sizeof(short));
								if (Signal.pTemp16 == NULL)
								{
									f_print_err_msg_and_exit("memory allocation"
										" not succeeded");
								}
								fread(Signal.pTemp16, sizeof(short),
									Signal.NumSamples, pfile);
								pData = Input->pData;
								pTemp16 = Signal.pTemp16;
								/*	Convert to double from integer-PCM	*/
								for (IdxTime = 0; IdxTime < Signal.NumSamples; IdxTime++)
								{
									*pData = ((double)*pTemp16) / 32768;
									pData++;
									pTemp16++;
								}
								free(Signal.pTemp16);
								Input->NumSamples = Signal.NumSamples;
								Input->SampleRate = (double)Signal.SampleRate;
							}
							else if (Signal.BitsPerSample == 32)
							{
								Input->pData = (double*)calloc(Signal.NumSamples,
									sizeof(double));
								if (Input->pData == NULL)
								{
									f_print_err_msg_and_exit("memory allocation"
										" not succeeded");
								}
								Signal.pTemp32 = (float*)calloc(Signal.NumSamples,
									sizeof(float));
								if (Signal.pTemp32 == NULL)
								{
									f_print_err_msg_and_exit("memory allocation"
										" not succeeded");
								}
								fread(Signal.pTemp32, sizeof(float),
									Signal.NumSamples, pfile);
								pData = Input->pData;
								pTemp32 = Signal.pTemp32;
								NanFoundInFile = 0;
								for (IdxTime = 0; IdxTime < Signal.NumSamples; IdxTime++)
								{
									if (!isnan(*pTemp32))
									{
										*pData = ((double)*pTemp32);
									}
									else
									{
										*pData = 0.0;
										NanFoundInFile = 1;
									}
									pData++;
									pTemp32++;
								}
								free(Signal.pTemp32);
								Input->NumSamples = Signal.NumSamples;
								Input->SampleRate = (double)Signal.SampleRate;
								if (NanFoundInFile == 1)
								{
									f_print_err_msg_and_exit("WAVE file may not"
										" contain NaN values");
								}
							}
							else
							{
								f_print_err_msg_and_exit("only 16-bit and 32-bit"
									" WAVE files are"
									" allowed");
							}
						}
						else
						{
							f_print_err_msg_and_exit("invalid header");
						}
					}
					else
					{
						f_print_err_msg_and_exit("only files containing one"
							" channel are allowed");
					}
				}
				else
				{
					f_print_err_msg_and_exit("only PCM and IEEE FLOAT wav"
						" files are allowed");
				}
			}
			else
			{
				f_print_err_msg_and_exit("not a WAVE file");
			}
		}
		else
		{
			f_print_err_msg_and_exit("not a RIFF file");
		}
		fclose(pfile);
	}
	else
	{
		f_print_err_msg_and_exit("file not found");
	}

	if (Signal.SampleRate != 48000)
	{
		if (Signal.SampleRate == 32000 || Signal.SampleRate == 44100)
		{
			retval = f_resample_to_48kHz(Input);
			if (retval < 0)
			{
				f_print_err_msg_and_exit("Resampling failed");
			}
		}
		else
		{
			f_print_err_msg_and_exit("only sampling rates of 32kHz, 44.1kHz"
				" or 48kHz supported");
		}
	}

	if (Signal.BitsPerSample == 32)
	{
		return	0;
	}
	else
	{
		return	1;
	}
}

//////////////////////////////////////////////////////////////////////////
//	BLOCK	Maximum and percentile calculation
//////////////////////////////////////////////////////////////////////////

/*	Returns maximum value of buffer										*/
double f_max_of_buffer(double *pSignal, int NumSamples)
{
	int		IdxTime;
	double	Maximum = 0;
	double	*pTmp = pSignal;

	for (IdxTime = 0; IdxTime < NumSamples; IdxTime++)
	{
		if (*pTmp > Maximum)
			Maximum = *pTmp;
		pTmp++;
	}
	return Maximum;
}

/*	Comparing function for qsort										*/
int f_compare(const void *a, const void *b)
{
	if (*(const double*)a < *(const double*)b)
		return -1;
	return *(const double*)a > *(const double*)b;
}

/*	Sorts buffer and computes percentile value							*/
double f_calc_percentile(double *pSignal, int Percentile, int NumSamples)
{
	int		Np = (int)((1 - Percentile / 100.) * (NumSamples));
	int		IdxTime;
	double	PercentileValue;
	double	*pSortBuffer, *pTmp1, *pTmp2 = pSignal;

	pSortBuffer = (double*)calloc(NumSamples, sizeof(double));
	if (pSortBuffer == NULL)
	{
		f_print_err_msg_and_exit("memory allocation not succeeded");
	}

	pTmp1 = pSortBuffer;

	/*	Copy buffer														*/
	for (IdxTime = 0; IdxTime < NumSamples; IdxTime++)
	{
		*pTmp1 = *pTmp2;
		pTmp1++;
		pTmp2++;
	}

	qsort(pSortBuffer, NumSamples, sizeof(double), f_compare);

	if (Percentile == 0)
		PercentileValue = *(pSortBuffer + NumSamples - 1);
	else if (Percentile == 100)
		PercentileValue = *pSortBuffer;
	else
		PercentileValue = (*(pSortBuffer + Np - 1) + *(pSortBuffer + Np)) / 2;

	free(pSortBuffer);

	return PercentileValue;
}

//////////////////////////////////////////////////////////////////////////
//	BLOCK	Write results to file
//////////////////////////////////////////////////////////////////////////

#define MAX_BUF_SIZE	256

/*	Output: write specific loudnesss to file							*/
void f_write_specloudness_to_file(double *pData[N_BARK_BANDS], 
	int NumSamples,
	int DecFactor, const char *pFileName,
	int SoundField,
	int SampleRateLoudness,
	int OutputPrecision,
	int OutputPercentile)
{
	int		Count, IdxTime, IdxFB;
	char	Str1[MAX_BUF_SIZE + 1],
			Strf[MAX_BUF_SIZE + 1],
			NameWithEnding[MAX_BUF_SIZE + 4 + 3 + 1];
	char    SoundFieldString[MAX_BUF_SIZE + 1];
	double	TimeRes = 1. / SampleRateLoudness * 1000;

	FILE	*pFile;

#if	USE_SECURE_CRT_FCTS
	errno_t Err;
#endif

#if	USE_SECURE_CRT_FCTS
	sprintf_s(NameWithEnding, MAX_BUF_SIZE + 4, "%s.csv", pFileName);

	sprintf_s(Strf, MAX_BUF_SIZE, "%%.%uf", OutputPrecision);

	Err = fopen_s(&pFile, NameWithEnding, "w");
	if (Err != 0)	/*	File is probably open							*/
#else
	sprintf(NameWithEnding, "%s.csv", pFileName);

	sprintf(Strf, "%%.%uf", OutputPrecision);

	pFile = fopen(NameWithEnding, "w");
	if (pFile == 0)	/*	File is probably open							*/
#endif
	{
		Count = 1;
#if	USE_SECURE_CRT_FCTS
		while (Err != 0 && Count < 10)
#else
		while (pFile == NULL && Count < 10)
#endif
		{
#if	USE_SECURE_CRT_FCTS
			sprintf_s(NameWithEnding, MAX_BUF_SIZE + 3, "%s(%u).csv", pFileName, Count);
			Err = fopen_s(&pFile, NameWithEnding, "w");
#else
			sprintf(NameWithEnding, "%s(%u).csv", pFileName, Count);
			pFile = fopen(NameWithEnding, "w");
#endif
			Count++;
		}
		if (Count == 10)
		{
#if	USE_SECURE_CRT_FCTS
			sprintf_s(Str1, MAX_BUF_SIZE, "could not write to file %s", NameWithEnding);
#else
			sprintf(Str1, "could not write to file %s", NameWithEnding);
#endif
			f_print_err_msg_and_exit(Str1);
		}
	}

	if (SoundField == SoundFieldDiffuse)
	{
#if	USE_SECURE_CRT_FCTS
		sprintf_s(SoundFieldString, MAX_BUF_SIZE, "diffuse field");
#else
		sprintf(SoundFieldString, "diffuse field");
#endif
	}
	else if (SoundField == SoundFieldFree)
	{
#if	USE_SECURE_CRT_FCTS
		sprintf_s(SoundFieldString, MAX_BUF_SIZE, "free field");
#else
		sprintf(SoundFieldString, "free field");
#endif
	}

#if	USE_SECURE_CRT_FCTS
	if (NumSamples > 1)
	{
		fprintf_s(pFile, "Specific loudness calculation according to ISO 532-1 for time varying sounds\n\n");
	}
	else
	{
		fprintf_s(pFile, "Specific loudness calculation according to ISO 532-1 for stationary sounds\n\n");
	}

	fprintf_s(pFile, "N' / (sone / Bark) (%s)\n;\n", SoundFieldString);

	fprintf_s(pFile, "t / s \\ Bark;", SoundFieldString);
	for (IdxFB = 0; IdxFB < N_BARK_BANDS; IdxFB++)
	{
		fprintf_s(pFile, Strf, (double)(IdxFB + 1) / (double)10);
		fprintf_s(pFile, ";");
	}
	fprintf_s(pFile, "\n");
#else
	if (NumSamples > 1)
	{
		fprintf(pFile, "Specific loudness calculation according to ISO 532-1 for time varying sounds;\n;\n");
	}
	else
	{
		fprintf(pFile, "Specific loudness calculation according to ISO 532-1 for stationary sounds;\n;\n");
	}

	fprintf(pFile, "N' / (sone / Bark) (%s)\n;\n", SoundFieldString);

	fprintf(pFile, "t / s \\ Bark;", SoundFieldString);
	for (IdxFB = 0; IdxFB < N_BARK_BANDS; IdxFB++)
	{
		fprintf(pFile, Strf, (double)(IdxFB + 1) / (double)10);
		fprintf(pFile, ";");
	}
	fprintf(pFile, "\n");
#endif

	for (IdxTime = 0; IdxTime < NumSamples; IdxTime+=DecFactor)
	{
#if	USE_SECURE_CRT_FCTS
		fprintf_s(pFile, Strf, (double) IdxTime / (double) SampleRateLoudness / (double) DecFactor);
		fprintf_s(pFile, ";");
#else
		fprintf(pFile, Strf, (double) IdxTime / (double) SampleRateLoudness / (double) DecFactor);
		fprintf(pFile, ";");
#endif
		for (IdxFB = 0; IdxFB < N_BARK_BANDS; IdxFB++)
		{
#if	USE_SECURE_CRT_FCTS
			fprintf_s(pFile, Strf, pData[IdxFB][IdxTime]);
			fprintf_s(pFile, ";");
#else
			fprintf(pFile, Strf, pData[IdxFB][IdxTime]);
			fprintf(pFile, ";");
#endif
		}
#if	USE_SECURE_CRT_FCTS
		fprintf_s(pFile, "\n");
#else
		fprintf(pFile, "\n");
#endif
	}
	fclose(pFile);
}

/*	Output: write loudness buffer to file								*/
void f_write_loudness_to_file(double *pData, int NumSamples,
	int DecFactor, const char *pFileName,
	double Maximum, double Percentile,
	int SoundField,
	int SampleRateLoudness,
	int OutputPrecision,
	int OutputPercentile)
{
	int		Count, IdxTime;
	char	Str1[MAX_BUF_SIZE + 1],
			Strf[MAX_BUF_SIZE + 1],
			NameWithEnding[MAX_BUF_SIZE + 4 + 3 + 1];
	char    SoundFieldString[MAX_BUF_SIZE + 1];
	double	TimeRes = 1. / SampleRateLoudness * 1000;
	double	*pTmp = pData;

	FILE	*pFile;

#if	USE_SECURE_CRT_FCTS
	errno_t Err;
#endif

#if	USE_SECURE_CRT_FCTS
	sprintf_s(NameWithEnding, MAX_BUF_SIZE + 4, "%s.csv", pFileName);

	sprintf_s(Strf, MAX_BUF_SIZE, "%%.%uf", OutputPrecision);

	Err = fopen_s(&pFile, NameWithEnding, "w");
	if (Err != 0)	/*	File is probably open							*/
#else
	sprintf(NameWithEnding, "%s.csv", pFileName);

	sprintf(Strf, "%%.%uf", OutputPrecision);

	pFile = fopen(NameWithEnding, "w");
	if (pFile == 0)	/*	File is probably open							*/
#endif
	{
		Count = 1;
#if	USE_SECURE_CRT_FCTS
		while (Err != 0 && Count < 10)
#else
		while (pFile == NULL && Count < 10)
#endif
		{
#if	USE_SECURE_CRT_FCTS
			sprintf_s(NameWithEnding, MAX_BUF_SIZE + 3, "%s(%u).csv", pFileName, Count);
			Err = fopen_s(&pFile, NameWithEnding, "w");
#else
			sprintf(NameWithEnding, "%s(%u).csv", pFileName, Count);
			pFile = fopen(NameWithEnding, "w");
#endif
			Count++;
		}
		if (Count == 10)
		{
#if	USE_SECURE_CRT_FCTS
			sprintf_s(Str1, MAX_BUF_SIZE, "could not write to file %s", NameWithEnding);
#else
			sprintf(Str1, "could not write to file %s", NameWithEnding);
#endif
			f_print_err_msg_and_exit(Str1);
		}
	}

	if (SoundField == SoundFieldDiffuse)
	{
#if	USE_SECURE_CRT_FCTS
		sprintf_s(SoundFieldString, MAX_BUF_SIZE, "diffuse field");
#else
		sprintf(SoundFieldString, "diffuse field");
#endif
	}
	else if (SoundField == SoundFieldFree)
	{
#if	USE_SECURE_CRT_FCTS
		sprintf_s(SoundFieldString, MAX_BUF_SIZE, "free field");
#else
		sprintf(SoundFieldString, "free field");
#endif
	}

#if	USE_SECURE_CRT_FCTS
	if (NumSamples > 1)
	{
		fprintf_s(pFile, "Loudness calculation according to ISO 532-1 for time varying sounds;\n;\n");

		sprintf_s(Str1, MAX_BUF_SIZE, Strf, Maximum);
		fprintf_s(pFile, "Nmax / sone (%s); %s\n", SoundFieldString, Str1);

		sprintf_s(Str1, MAX_BUF_SIZE, Strf, Percentile);
		fprintf_s(pFile, "N%u / sone (%s); %s\n", OutputPercentile, SoundFieldString, Str1);

		fprintf_s(pFile, ";\nt / s; N / sone (%s)\n", SoundFieldString);
		for (IdxTime = 0; IdxTime < NumSamples / DecFactor; IdxTime++)
		{
			fprintf_s(pFile, Strf, (double)IdxTime / (double)SampleRateLoudness);
			fprintf_s(pFile, ";");
			fprintf_s(pFile, Strf, *pData);
			fprintf_s(pFile, "\n");
			pData += DecFactor;
		}
	}
	else
	{
		fprintf_s(pFile, "Loudness calculation according to ISO 532-1 for stationary sounds;\n;\n");

		sprintf_s(Str1, MAX_BUF_SIZE, Strf, Maximum);
		fprintf_s(pFile, "N / sone (%s); %s\n", SoundFieldString, Str1);

		sprintf_s(Str1, MAX_BUF_SIZE, Strf, f_sone_to_phon(Maximum));
		fprintf_s(pFile, "LN / phon (%s); %s\n", SoundFieldString, Str1);
	}

#else
	if (NumSamples > 1)
	{
		fprintf(pFile, "Loudness calculation according to ISO 532-1 for time varying sounds;\n;\n");

		sprintf(Str1, Strf, Maximum);
		fprintf(pFile, "Nmax / sone (%s); %s\n", SoundFieldString, Str1);

		sprintf(Str1, Strf, Percentile);
		fprintf(pFile, "N%u / sone (%s); %s\n", OutputPercentile, SoundFieldString, Str1);

		fprintf(pFile, ";\nt / s; N / sone (%s)\n", SoundFieldString);
		for (IdxTime = 0; IdxTime < NumSamples / DecFactor; IdxTime++)
		{
			fprintf(pFile, Strf, (double)IdxTime / (double)SampleRateLoudness);
			fprintf(pFile, ";");
			fprintf(pFile, Strf, *pData);
			fprintf(pFile, "\n");
			pData += DecFactor;
		}
	}
	else
	{
		fprintf(pFile, "Loudness calculation according to ISO 532-1 for stationary sounds;\n;\n");

		sprintf(Str1, Strf, Maximum);
		fprintf(pFile, "N / sone (%s); %s\n", SoundFieldString, Str1);

		sprintf(Str1, Strf, f_sone_to_phon(Maximum));
		fprintf(pFile, "LN / phon (%s); %s\n", SoundFieldString, Str1);
	}

#endif
	fclose(pFile);
}

/*	 Decimation by DecFactor											*/
int	f_downsampling(double *pInput, double *pOutput, int NumInSamples,
	int DecFactor)
{
	int		IdxTime, NumOutSamples;
	double	*pX = pInput
		,	*pY = pOutput;

	NumOutSamples = NumInSamples / DecFactor;

	for (IdxTime = 0; IdxTime < NumOutSamples; IdxTime++)
	{
		*pY = *pX;
		pX += DecFactor;
		pY++;
	}

	return NumOutSamples;
}

/*	Conversion from sone to phon										*/
double f_sone_to_phon(double Loudness)
{
	double	LoudnessLevel;

	if (Loudness < 1.f)
	{
		LoudnessLevel = 40. * pow(Loudness + .0005, .35);
		if (LoudnessLevel < 3.)
			LoudnessLevel = 3.;
	}
	else
	{
		LoudnessLevel = 10. * log(Loudness) / log(2.) + 40.;
	}
	return LoudnessLevel;
}

/*	Replace commas in a string with a dot								*/
void f_replace_comma_with_dot(char* value, int length)
{
	int		i;

	for (i = 0; i < length; i++)
	{
		if (value[i] == ',')
		{
			value[i] = '.';
		}
	}
}

/*	Check if the string is a colon separated list, i.e. contains 
	at least one colon.													*/
int f_is_colon_separated_list(char* value, int length)
{
	int		i;
	int		counter = 0;

	for (i = 0; i < length; i++)
	{
		if (value[i] == ':')
		{
			counter++;
		}
	}
	if (counter == N_LEVEL_BANDS - 1)
	{
		return 1;
	}
	return 0;
}

/* Read 28 third octave levels from a colon separated list				*/
int f_levels_from_list(double** ThirdOctaveLevels, char* listString, 
	int length)
{
	int		valueCounter = 0;
	int		startPosition = 0;
	int		endPosition = 0;
	double	value;

	while (valueCounter < N_LEVEL_BANDS - 1 && endPosition < length)
	{
		if (listString[endPosition] != ':')
		{
			endPosition++;
		}
		else
		{
			endPosition++;
			value = atof(listString + startPosition);
			ThirdOctaveLevels[valueCounter][0] = value;
			valueCounter++;
			startPosition = endPosition;
		}
	}
	if (valueCounter == N_LEVEL_BANDS - 1 && startPosition < length)
	{
		value = atof(listString + startPosition);
		ThirdOctaveLevels[valueCounter][0] = value;
	}
	else
	{
		return -1;
	}
	return 0;
}

/*	Check if string is an empty line, i.e. only white space				*/
static int f_is_empty_line(char* buffer, int bufferSize)
{
	int		i;

	for (i = 0; i < bufferSize; i++)
	{
		if (buffer[i] == 0)
		{
			break;
		}
		if (buffer[i] != ' ' && buffer[i] != '\t' && buffer[i] != '\n')
		{
			return 0;
		}
	}
	return 1;
}

/*	Read next non-comment and non-empty line from text file				*/
static int f_read_next_line(char* buffer, int bufferSize, FILE* file)
{
	char	*result;

	while (1)
	{
		result = fgets(buffer, bufferSize, file);
		/*	Eof, error,  or line too long								*/
		if (result == NULL || strnlen(buffer, bufferSize) == bufferSize - 1)
		{
			return -1;
		}

		/*	Ignore lines starting with #								*/
		if (buffer[0] != '#' && f_is_empty_line(buffer, MAX_BUF_SIZE) == 0)
		{
			return strnlen(buffer, MAX_BUF_SIZE);
		}
	}
}

/*	Read 28 third octave levels from file								*/
int f_levels_from_file(double** ThirdOctaveLevels, char* filename)
{
	FILE	*pfile;
	char	line[MAX_BUF_SIZE];
	int		resultLength;
	int		startPosition;
	double	value;
	int		valueCounter = 0;

#if	USE_SECURE_CRT_FCTS
	errno_t Err;
#endif

#if	USE_SECURE_CRT_FCTS
	Err = fopen_s(&pfile, filename, "rb");
	if (Err == 0)
#else
	pfile = fopen(filename, "rb");
	if (pfile != 0)
#endif
	{
		valueCounter = 0;
		while (valueCounter < N_LEVEL_BANDS)
		{
			/*	Read next line											*/
			resultLength = f_read_next_line(line, MAX_BUF_SIZE, pfile);
			if (resultLength < 0)
			{
				f_print_err_msg_and_exit("Error while reading file.");
			}

			/*	Replace commas with dots								*/
			f_replace_comma_with_dot(line, resultLength);

			/*	Find colon and interpret rest of the line as level 
				value													*/
			startPosition = 0;
			while (startPosition < resultLength && line[startPosition] != ':')
			{
				startPosition++;
			}
			startPosition++;	/* Skip colon							*/

			if (startPosition < resultLength)
			{
				value = atof(line + startPosition);
				ThirdOctaveLevels[valueCounter][0] = value;
				valueCounter++;
			}
			else
			{
				f_print_err_msg_and_exit("Invalid line in file.");
			}
		}
	}
	else
	{
		f_print_err_msg_and_exit("Opening file failed.");
	}

	fclose(pfile);
	return 0;
}
