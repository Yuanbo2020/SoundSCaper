/************************************************************************/
/*  Loudness calculation according to ISO 532-1,                        */
/*  methods for stationary and time varying signals                     */
/*  Helper methods                                                      */
/************************************************************************/

#ifndef HEADER_ISO_532_1_HELPER
#define HEADER_ISO_532_1_HELPER

#ifdef __cplusplus 
extern "C"
{
#endif

#define	USE_SECURE_CRT_FCTS		1

#if !USE_SECURE_CRT_FCTS 
#define _CRT_SECURE_NO_WARNINGS	1
#endif

struct InputData;

/*	Error messages														*/
void f_print_err_msg_and_exit(const char *pMsg);

/*	Sorts buffer and computes percentile value							*/
double f_calc_percentile(double *pSignal, int Percentile, int NumSamples);

/*	Output: write loudness to file										*/
void f_write_loudness_to_file(double *pData, int NumSamples,
	int DecFactor, const char *pFileName,
	double Maximum, double Percentile,
	int SoundField,
	int SampleRateLoudness,
	int OutputPrecision,
	int OutputPercentile);

/*	Output: write specific loudnesss to file							*/
void f_write_specloudness_to_file(double *pData[N_BARK_BANDS], int NumSamples,
	int DecFactor, const char *pFileName,
	int SoundField,
	int SampleRateLoudness,
	int OutputPrecision,
	int OutputPercentile);

/*	 Decimation by DecFactor											*/
int	f_downsampling(double *pInput, double *pOutput, int NumInSamples,
	int DecFactor);

double f_max_of_buffer(double *pSignal, int NumSamples);

/*	Conversion from sone to phon										*/
double f_sone_to_phon(double Loudness);

/* Replace commas in a string with a dot								*/
void f_replace_comma_with_dot(char* value, int length);

/* Check if the string is a colon separated list, i.e. contains
	at least one colon.													*/
int f_is_colon_separated_list(char* value, int length);

/* Read 28 third octave levels from a colon separated list				*/
int f_levels_from_list(double** ThirdOctaveLevels, char* listString, int length);

/* Read 28 third octave levels from file								*/
int f_levels_from_file(double** ThirdOctaveLevels, char* filename);

/*  Resamples signal from 44.1kHz or 32kHz to 48kHz						*/
int f_resample_to_48kHz(struct InputData *pSignal);

/*  Read wav input-file													*/
int f_read_wavfile(const char *pFileName, struct InputData *Input);

#ifdef __cplusplus 
}
#endif

#endif //HEADER_ISO_532_1_HELPER