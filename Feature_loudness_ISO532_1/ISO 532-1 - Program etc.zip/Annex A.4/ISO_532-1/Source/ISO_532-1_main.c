﻿/************************************************************************/
/*  Loudness calculation according to ISO 532-1,                        */
/*  methods for stationary and time varying signals                     */
/************************************************************************/

#include "ISO_532-1.h"
#include "ISO_532-1_helper.h"

#include <locale.h>
#include <string.h>
#include <stdio.h>
#include <math.h>     /* for atof										*/
#include <stdlib.h>   /* for free, calloc								*/
#include <errno.h>

#define MAX_BUF_SIZE 256

/*	Name of output file (*.csv) for specific loudness					*/
const char*	SPECL_OUT_NAME = "SpecLoudness";
/*	Output: number of digits after comma								*/
const int	OUTPUT_PREC = 4;
/*	% percentile to output												*/
const int	P_OUTPUT = 5;
/*	Name of output file for loudness (saved as *.csv)					*/
const char* LOUD_OUT_NAME = "Loudness";

/*	Sampling rate to which output/total summed loudness is downsampled	*/
const int	SR_LOUDNESS = 500;

enum _CalculationMode
{
	CalculationModeFromLevels,
	CalculationModeFromSignal,
	CalculationModeInvalid,
};

//////////////////////////////////////////////////////////////////////////
//  BLOCK   Main (example)
//////////////////////////////////////////////////////////////////////////

/*	How to call function from command line:

	ISO_532-1 Stationary   F|D <input file> [ <ref. file> <ref. level> ] <time skip value>
		Stationary   loudness with given WAVE input file with 32-bit 
		float format for free field (F) or diffuse field (D). 
		Do not consider first <time skip> seconds for calculating third 
		octave levels, e.g. <time skip> = 0.2.
		If <input file> is in 16-bit integer format, a reference file
		<ref. file> and a reference level <ref. level> (rms) must be provided.

	ISO_532-1 Stationary   F|D <input file>
		Stationary   loudness with given third octave levels from input file
		for free field (F) or diffuse field (D). 

	ISO_532-1 Stationary   F|D <third octave levels>
		Stationary   loudness with given third octave levels (28 levels)
		for free field (F) or diffuse field (D).
		Separate third octave levels must be separated by a colon with no white 
		space.

	ISO_532-1 Time_varying F|D <input file> [ <ref. file> <ref. level> ] 
		Time-varying loudness with given WAVE input file with 32-bit
		float format for free field (F) or diffuse field (D). 
		If <input file> is in 16-bit integer format, a reference file
		<ref. file> and a reference level <ref. level> (rms) must be provided.

	*	Supported sound files are 16-bit integer or 32-bit float WAVE files 
		(correct sound pressure values, no normalized data) containing one 
		channel!
	*	Sampling rates must be 32 kHz, 44.1 kHz or 48 kHz!
	*	Stationary signals should be longer than <time skip> seconds (start of
		signal not used for level calculation)!
	*	For level input, a text file format is supported with two colon 
		separated columns. The first column lists the mid frequencies of the 
		frequency bands and the second column the corresponding third octave 
		levels. There must be exactly 28 level entries in the file. The mid 
		frequencies are not evaluated, they are only for orientation. White 
		space and empty lines as well as lines starting with # are ignored.

	Examples:

	Calculate loudness of audio signal in soundfile32.wav (32-bit format) with 
	the method for stationary sounds, for free field, and with a time skip of 
	0.2 seconds.
	> ISO_532-1 Stationary F soundfile32.wav 0.2

	Calculate loudness of audio signal in soundfile16.wav (16-bit format) with 
	the method for stationary sounds, for diffuse field, with the reference 
	file referencefile16.wav, a reference level of 40 dB, and a time skip of 
	0.2 seconds.
	> ISO_532-1 Stationary D soundfile16.wav referencefile16.wav 40 0.2

	Calculate loudness for third octave levels given on the command line for free field
	> ISO_532-1 Stationary F 0:0:0:0:0:0:0:0:0:0:0:0:0:0:20:40:20:0:0:0:0:0:0:0:0:0:0:0
*/
int main( int argc, char *argv[] ) 
{
	char    InputName[MAX_BUF_SIZE];
	char    ReferenceName[MAX_BUF_SIZE];
	char	CmdArgBuffer[MAX_BUF_SIZE];

	double	*ThirdOctaveLevel[N_LEVEL_BANDS];

	int     ReferenceFileNeeded;
	int     currentCmdArgIndex;
	int     SoundField;
	int     Method;
	int     IdxTime;
	int     IdxFB;

	int		CalculationMode = CalculationModeInvalid;

	int     retval;

	double  ReferenceLevel;
	double  IntensSum;
	double  CalFactor;
	double  TimeSkip;
	double	*pData;
	double  Maximum;
	double  Percentile;
	double  LoudnessLevel;
	char	SoundFieldString[MAX_BUF_SIZE];

	struct	InputData Signal, RefSignal;

	double	*OutLoudness;
	double	*OutSpecLoudness[N_BARK_BANDS];

	int		DecFactorLevel     = 1;
	int		DecFactorLoudness  = 1;
	double	SampleRateLevel    = 1;
	int		SampleRateLoudness = 1;
	int		NumSamplesLevel    = 1;
	int		NumSamplesLoudness = 1;

	for (IdxFB = 0; IdxFB < N_LEVEL_BANDS; IdxFB++)
	{
		ThirdOctaveLevel[IdxFB] = NULL;
	}

	/*	Function atof uses current locale for number conversion.
		Set it to English to have '.' for decimal point.
		In numeric strings ',' will be replaced with '.' to be compatible
		with this locale.
		The locale will be reset do default later.						*/
	setlocale(LC_ALL, "English"); 

	/*	First argument: (Stationary|Time_varying)						*/
	currentCmdArgIndex = 1;
	if (argc > currentCmdArgIndex)
	{
		strncpy(CmdArgBuffer, argv[currentCmdArgIndex], MAX_BUF_SIZE);
		CmdArgBuffer[4] = 0;
		if (_strnicmp(CmdArgBuffer, "STAT", 4) == 0)
		{
			Method = LoudnessMethodStationary;
		}
		else if (_strnicmp(CmdArgBuffer, "TIME", 4) == 0)
		{
			Method = LoudnessMethodTimeVarying;
		}
		else
		{
			f_print_err_msg_and_exit("Unsupported loudness method.");
		}
	}

	/*	Second argument: (F|D)											*/
	currentCmdArgIndex = 2;
	if (argc > currentCmdArgIndex)
	{
		strncpy(CmdArgBuffer, argv[currentCmdArgIndex], MAX_BUF_SIZE);
		CmdArgBuffer[1] = 0;
		if (_strnicmp(CmdArgBuffer, "D", 1) == 0)
		{
			SoundField = SoundFieldDiffuse;
		}
		else if (_strnicmp(CmdArgBuffer, "F", 1) == 0)
		{
			SoundField = SoundFieldFree;
		}
		else
		{
			f_print_err_msg_and_exit("Unsupported sound field type.");
		}
	}

	/*	Third argument:
			if Method == LoudnessMethodStationary
				argc == 4: 28 colon separated levels or text file with levels
				argc == 5: 32-bit float WAVE file
				argc == 7: 16-bit integer WAVE file
			if Method == LoudnessMethodTimeVarying
				argc == 4: 32-bit float WAVE file
				argc == 6: 16-bit integer WAVE file						*/
	
	currentCmdArgIndex = 3;
	if (argc > currentCmdArgIndex)
	{
		/*	Use WAVE file as input										*/
		if ((Method == LoudnessMethodStationary && argc > currentCmdArgIndex + 1)
			|| (Method == LoudnessMethodTimeVarying && argc > currentCmdArgIndex))
		{
			CalculationMode = CalculationModeFromSignal;

			strncpy(InputName, argv[currentCmdArgIndex], MAX_BUF_SIZE);
			InputName[MAX_BUF_SIZE - 1] = 0;

			ReferenceFileNeeded = f_read_wavfile(InputName, &Signal);

			currentCmdArgIndex = 4;
			if (argc > currentCmdArgIndex + 1)
			{
				/*	Fourth argument:
						name of reference file							*/
				strncpy(ReferenceName, argv[currentCmdArgIndex], MAX_BUF_SIZE);
				ReferenceName[MAX_BUF_SIZE - 1] = 0;

				/*	Fifth argument:
						reference level									*/
				currentCmdArgIndex = 5;
				strncpy(CmdArgBuffer, argv[currentCmdArgIndex], MAX_BUF_SIZE);
				CmdArgBuffer[MAX_BUF_SIZE - 1] = 0;

				f_replace_comma_with_dot(CmdArgBuffer, MAX_BUF_SIZE);

				ReferenceLevel = atof(CmdArgBuffer);
				if (ReferenceLevel < 20 || ReferenceLevel > 120)
				{
					f_print_err_msg_and_exit("please choose 20 < "
						"'Calibration level in dB rms' < 120");
				}

				/*	Read reference file									*/
				if (f_read_wavfile(ReferenceName, &RefSignal) != 1)
				{
					f_print_err_msg_and_exit("Reference file contains no "
						"integer data");
				}

				/*	Calculate calibration factor						*/
				pData = RefSignal.pData;
				IntensSum = 0;
				for (IdxTime = 0; IdxTime < RefSignal.NumSamples; IdxTime++)
				{
					IntensSum += pow(*pData, 2);
					pData++;
				}
				IntensSum /= RefSignal.NumSamples;
				CalFactor = sqrt(pow(10, ReferenceLevel / 10) * I_REF / IntensSum);

				free(RefSignal.pData);

				/*	Apply calibration factor to input signal			*/
				pData = Signal.pData;
				for (IdxTime = 0; IdxTime < Signal.NumSamples; IdxTime++)
				{
					*pData *= CalFactor;
					pData++;
				}

				/*	Set index of next cmd arg							*/
				currentCmdArgIndex = 6;
			}
			else
			{
				if (ReferenceFileNeeded == 1)
				{
					f_print_err_msg_and_exit("For integer data please specify "
						"calibration file and calibration level");
				}
			}

			/*	Fourth or sixth argument 
				(when Method == LoudnessMethodStationary): time skip	*/
			if (Method == LoudnessMethodStationary)
			{
				if (argc > currentCmdArgIndex)
				{
					strncpy(CmdArgBuffer, argv[currentCmdArgIndex], MAX_BUF_SIZE);
					CmdArgBuffer[MAX_BUF_SIZE - 1] = 0;

					f_replace_comma_with_dot(CmdArgBuffer, MAX_BUF_SIZE);

					TimeSkip = atof(CmdArgBuffer);
					if (TimeSkip < 0 || TimeSkip > 1)
					{
						f_print_err_msg_and_exit("0 <= <time skip value> / s <= 1");
					}
					if (TimeSkip >= Signal.NumSamples / Signal.SampleRate)
					{
						f_print_err_msg_and_exit("<time skip value> >= signal duration");
					}
				}
				else
				{
					f_print_err_msg_and_exit("Input argument <time skip value> "
						"missing.");
				}
			}
		}
		/*	Direct input of levels										*/
		else
		{
			CalculationMode = CalculationModeFromLevels;

			NumSamplesLevel = 1;

			/*	Memory allocation										*/
			for (IdxFB = 0; IdxFB < N_LEVEL_BANDS; IdxFB++)
			{
				ThirdOctaveLevel[IdxFB] = (double*)calloc(NumSamplesLevel, sizeof(double));
				if (ThirdOctaveLevel[IdxFB] == NULL)
				{
					f_print_err_msg_and_exit("memory allocation not succeeded");
				}
			}

			/*	Check loudness method									*/
			if (Method == LoudnessMethodTimeVarying)
			{
				f_print_err_msg_and_exit("Direct input of third octave levels only "
					"supported for stationary method.");
			}

			/*	Copy argument											*/
			strncpy(CmdArgBuffer, argv[currentCmdArgIndex], MAX_BUF_SIZE);
			CmdArgBuffer[MAX_BUF_SIZE - 1] = 0;

			/*	If colon separated list, this argument is a list of 
				third octave levels,									*/
			if (f_is_colon_separated_list(CmdArgBuffer, MAX_BUF_SIZE))
			{
				f_replace_comma_with_dot(CmdArgBuffer, MAX_BUF_SIZE);

				retval = f_levels_from_list(ThirdOctaveLevel, CmdArgBuffer, MAX_BUF_SIZE);
				if (retval < 0)
				{
					f_print_err_msg_and_exit("Extraction of level values from input argument failed.");
				}
			}
			/*	otherwise it is assumed to be the filename of a file 
				containing the 	third octave levels.					*/
			else
			{
				retval = f_levels_from_file(ThirdOctaveLevel, CmdArgBuffer);
				if (retval < 0)
				{
					f_print_err_msg_and_exit("Reading levels from file failed.");
				}
			}
		}
	}

	/*	Set locate back to default										*/
	setlocale(LC_ALL, "");

	if (Method == LoudnessMethodTimeVarying) /* Always from signal		*/
	{
		SampleRateLevel = SR_LEVEL;
		SampleRateLoudness = SR_LOUDNESS;
		DecFactorLevel = (int)(Signal.SampleRate / SampleRateLevel);
		DecFactorLoudness = (int)(SampleRateLevel / SampleRateLoudness);
		NumSamplesLevel = Signal.NumSamples / DecFactorLevel;
		NumSamplesLoudness = NumSamplesLevel / DecFactorLoudness;
	}

	/*	Memory allocation												*/
	OutLoudness = (double*)calloc(NumSamplesLevel, sizeof(double));
	if (OutLoudness == NULL)
	{
		f_print_err_msg_and_exit("memory allocation not succeeded");
	}

	for (IdxFB = 0; IdxFB < N_BARK_BANDS; IdxFB++)
	{
		OutSpecLoudness[IdxFB] = (double*)calloc(NumSamplesLevel, sizeof(double));
		if (OutSpecLoudness[IdxFB] == NULL)
		{
			f_print_err_msg_and_exit("memory allocation not succeeded");
		}
	}

	/*	Acutal loudness calculation										*/
	if (CalculationMode == CalculationModeFromSignal)
	{
		retval = f_loudness_from_signal(&Signal, SoundField, Method, TimeSkip,
			OutLoudness, OutSpecLoudness, NumSamplesLevel);
	}
	else if (CalculationMode == CalculationModeFromLevels)
	{
		retval = f_loudness_from_levels(ThirdOctaveLevel, NumSamplesLevel, SoundField, 
			Method, OutLoudness, OutSpecLoudness);
	}
	else
	{
		f_print_err_msg_and_exit("Internal error occurred.");
	}

	if (retval < 0)
	{
		switch (retval)
		{
			case LoudnessErrorMemoryAllocFailed:
				f_print_err_msg_and_exit("memory allocation not succeeded");
				break;
			case LoudnessErrorOutputVectorTooSmall:
				f_print_err_msg_and_exit("result vector too small");
				break;
			default:
				f_print_err_msg_and_exit("An error occurred during loudness calculation.");
				break;
		}
	}

	NumSamplesLevel = retval;

	/*	Memory deallocation												*/
	for (IdxFB = 0; IdxFB < N_LEVEL_BANDS; IdxFB++)
	{
		if (ThirdOctaveLevel[IdxFB] != NULL)
			free(ThirdOctaveLevel[IdxFB]);
	}

	/*	Postprocessing													*/

	switch (SoundField)
	{
		case SoundFieldDiffuse:
			sprintf(SoundFieldString, "diffuse field");
			break;
		case SoundFieldFree:
			sprintf(SoundFieldString, "free field");
			break;
		default:
			f_print_err_msg_and_exit("Invalid sound field type.");
			break;
	}

	/*	Downsampling to SR_LOUDNESS	for time varying loudness			*/
	if (Method == LoudnessMethodTimeVarying)
	{
		f_write_specloudness_to_file(OutSpecLoudness, NumSamplesLevel, DecFactorLoudness,
			SPECL_OUT_NAME,
			SoundField, SampleRateLoudness, OUTPUT_PREC, P_OUTPUT);

		NumSamplesLoudness = f_downsampling(OutLoudness, OutLoudness, NumSamplesLevel,
			DecFactorLoudness);

		Maximum = f_max_of_buffer(OutLoudness, NumSamplesLoudness);
		Percentile = f_calc_percentile(OutLoudness, P_OUTPUT, NumSamplesLoudness);

		f_write_loudness_to_file(OutLoudness, NumSamplesLoudness, 1, 
			LOUD_OUT_NAME,	Maximum, Percentile, 
			SoundField, SampleRateLoudness, OUTPUT_PREC, P_OUTPUT);

		LoudnessLevel = f_sone_to_phon(Percentile);

		printf("\nLoudness (Nmax) / sone (%s): %6.2f\n\nLoudness (N%d) /sone (%s): %6.2f\n",
			SoundFieldString, Maximum,
			P_OUTPUT, SoundFieldString, Percentile
			);
	}
	else
	{
		f_write_specloudness_to_file(OutSpecLoudness, NumSamplesLevel, DecFactorLoudness,
			SPECL_OUT_NAME,
			SoundField, SampleRateLoudness, OUTPUT_PREC, P_OUTPUT);

		f_write_loudness_to_file(OutLoudness, NumSamplesLevel, 1,
			LOUD_OUT_NAME, OutLoudness[0], OutLoudness[0],
			SoundField, SampleRateLoudness, OUTPUT_PREC, P_OUTPUT);

		LoudnessLevel = f_sone_to_phon(OutLoudness[0]);
		printf("\nLoudness (N) / sone (%s): %6.2f\n\nLoudness level (LN) / phon (%s): %5.1f\n"
			, SoundFieldString, OutLoudness[0]
			, SoundFieldString, LoudnessLevel
			);
	}

	return 0;
}
